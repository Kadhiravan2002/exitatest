import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import DashboardHeader from "@/components/DashboardHeader";
import {
  Users,
  FileText,
  AlertCircle,
  TrendingUp,
  Building,
  UserCheck,
  Calendar,
  Eye,
  BarChart3,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

export default function PrincipalDashboard() {
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalStaff: 0,
    pendingRequests: 0,
    pendingComplaints: 0,
    approvedToday: 0,
    rejectedToday: 0,
  });
  const [outingRequests, setOutingRequests] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [notices, setNotices] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);

      // Fetch statistics
      const [
        studentsData,
        staffData,
        outingData,
        complaintsData,
        noticesData,
        activityData,
      ] = await Promise.all([
        supabase
          .from("profiles")
          .select("*")
          .eq("role", "student")
          .eq("is_approved", true),
        supabase
          .from("profiles")
          .select("*")
          .in("role", ["advisor", "hod", "warden", "admin"]),
        supabase.from("outing_requests").select(`
          *,
          profiles!outing_requests_student_id_fkey(full_name, student_id)
        `),
        supabase.from("complaints").select("*"),
        supabase.from("notices").select("*").order("created_at", { ascending: false }).limit(5),
        supabase
          .from("approval_history")
          .select(`
            *,
            outing_requests(
              reason,
              profiles!outing_requests_student_id_fkey(full_name)
            )
          `)
          .order("created_at", { ascending: false })
          .limit(10),
      ]);

      const today = new Date().toISOString().split("T")[0];
      const approvedToday = outingData.data?.filter(
        (req) => req.final_status === "approved" && req.updated_at?.startsWith(today)
      ).length || 0;
      const rejectedToday = outingData.data?.filter(
        (req) => req.final_status === "rejected" && req.updated_at?.startsWith(today)
      ).length || 0;

      setStats({
        totalStudents: studentsData.data?.length || 0,
        totalStaff: staffData.data?.length || 0,
        pendingRequests: outingData.data?.filter((req) => req.final_status === "pending").length || 0,
        pendingComplaints: complaintsData.data?.filter((comp) => comp.status === "pending").length || 0,
        approvedToday,
        rejectedToday,
      });

      setOutingRequests(outingData.data || []);
      setComplaints(complaintsData.data || []);
      setNotices(noticesData.data || []);
      setRecentActivity(activityData.data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    };
    return (
      <Badge className={statusColors[status as keyof typeof statusColors] || "bg-gray-100 text-gray-800"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        title="Principal Dashboard" 
        subtitle="System overview and institutional insights" 
        userRole="principal" 
      />
      <main className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Refresh Button */}
          <div className="flex justify-end">
            <Button onClick={fetchDashboardData} variant="outline" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Refresh Data
            </Button>
          </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalStudents}</div>
              <p className="text-xs text-muted-foreground">Active registered students</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
              <UserCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalStaff}</div>
              <p className="text-xs text-muted-foreground">Faculty & administration</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingRequests}</div>
              <p className="text-xs text-muted-foreground">Awaiting approval</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Complaints</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingComplaints}</div>
              <p className="text-xs text-muted-foreground">Unresolved issues</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Approved Today</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.approvedToday}</div>
              <p className="text-xs text-muted-foreground">Today's approvals</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Rejected Today</CardTitle>
              <XCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.rejectedToday}</div>
              <p className="text-xs text-muted-foreground">Today's rejections</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="requests">Outing Requests</TabsTrigger>
            <TabsTrigger value="complaints">Complaints</TabsTrigger>
            <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Notices */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Recent Notices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {notices.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4">No notices available</p>
                    ) : (
                      notices.slice(0, 5).map((notice: any) => (
                        <div key={notice.id} className="border-b pb-2 last:border-b-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{notice.title}</h4>
                              <p className="text-xs text-muted-foreground mt-1">
                                {formatDate(notice.created_at)}
                              </p>
                            </div>
                            {notice.is_urgent && (
                              <Badge variant="destructive" className="text-xs">
                                Urgent
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* System Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    System Health
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Request Processing</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        Normal
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Complaint Resolution</span>
                      <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                        Attention Needed
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">User Activity</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        Active
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="requests" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>All Outing Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {outingRequests.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No outing requests found</p>
                  ) : (
                    outingRequests.slice(0, 10).map((request: any) => (
                      <div key={request.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-medium">
                              {request.profiles?.full_name} ({request.profiles?.student_id})
                            </h4>
                            <p className="text-sm text-muted-foreground mt-1">{request.reason}</p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                              <span>Type: {request.outing_type}</span>
                              <span>Destination: {request.destination}</span>
                              <span>Stage: {request.current_stage}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            {getStatusBadge(request.final_status)}
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatDate(request.created_at)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="complaints" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Complaint Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {complaints.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No complaints found</p>
                  ) : (
                    complaints.slice(0, 10).map((complaint: any) => (
                      <div key={complaint.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-medium">{complaint.title}</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              Category: {complaint.category}
                            </p>
                            <p className="text-sm mt-2 line-clamp-2">{complaint.description}</p>
                          </div>
                          <div className="text-right">
                            {getStatusBadge(complaint.status)}
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatDate(complaint.created_at)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent System Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No recent activity</p>
                  ) : (
                    recentActivity.map((activity: any) => (
                      <div key={activity.id} className="border-b pb-3 last:border-b-0">
                        <div className="flex items-start gap-3">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                          <div className="flex-1">
                            <p className="text-sm">
                              <span className="font-medium">{activity.action}</span> by {activity.stage} stage
                            </p>
                            {activity.outing_requests && (
                              <p className="text-xs text-muted-foreground">
                                Request: {activity.outing_requests.reason} by{" "}
                                {activity.outing_requests.profiles?.full_name}
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground">
                              {formatDate(activity.created_at)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        </div>
      </main>
    </div>
  );
}