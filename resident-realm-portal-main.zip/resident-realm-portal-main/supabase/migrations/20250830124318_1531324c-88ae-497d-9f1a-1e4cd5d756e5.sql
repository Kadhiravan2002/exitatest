-- Add principal to the user_role enum
ALTER TYPE user_role ADD VALUE 'principal';